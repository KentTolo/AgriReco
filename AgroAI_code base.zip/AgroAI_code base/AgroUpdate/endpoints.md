Here's a complete list of endpoints for your FastAPI application with instructions for testing each one using **Postman** or **cURL**:

---

### 🌐 **API Endpoints & Testing Guide**

#### **1. Root Endpoint**  
**GET** `/`  
**Description**: Basic health check.  
**Test**:  
```bash
curl http://localhost:8000/
```
**Expected Response**:  
```json
{"message": "Welcome to FastAPI with PostgreSQL Authentication"}
```

---

#### **2. User Registration**  
**POST** `/register`  
**Description**: Register a new user.  
**Headers**:  
- `Content-Type: application/json`  

**Body (JSON)**:  
```json
{
  "email": "user@example.com",
  "full_name": "John Doe",
  "password": "securepassword123"
}
```
**Test**:  
```bash
curl -X POST http://localhost:8000/register \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com", "full_name":"John Doe", "password":"securepassword123"}'
```
**Success Response (201)**:  
```json
{
  "user_id": "a1b2c3d4-...",
  "email": "user@example.com",
  "full_name": "John Doe",
  "created_at": "2023-11-20T12:00:00Z",
  "last_login": null
}
```
**Error Cases**:  
- **400**: Email already exists.  
- **500**: Server error (e.g., database issue).

---

#### **3. Login (Get JWT Token)**  
**POST** `/token`  
**Description**: Authenticate and receive a JWT token.  
**Headers**:  
- `Content-Type: application/x-www-form-urlencoded`  

**Body (Form-Data)**:  
- `username`: user@example.com  
- `password`: securepassword123  

**Test**:  
```bash
curl -X POST http://localhost:8000/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=user@example.com&password=securepassword123"
```
**Success Response (200)**:  
```json
{
  "access_token": "eyJhbGciOi...",
  "token_type": "bearer"
}
```
**Error Cases**:  
- **401**: Invalid email/password.

---

#### **4. Get Current User**  
**GET** `/users/me`  
**Description**: Fetch logged-in user details (requires JWT).  
**Headers**:  
- `Authorization: Bearer <JWT_TOKEN>`  

**Test**:  
```bash
curl http://localhost:8000/users/me \
  -H "Authorization: Bearer eyJhbGciOi..."
```
**Success Response (200)**:  
```json
{
  "user_id": "a1b2c3d4-...",
  "email": "user@example.com",
  "full_name": "John Doe",
  "created_at": "2023-11-20T12:00:00Z",
  "last_login": null
}
```
**Error Cases**:  
- **401**: Missing/invalid token.

---

#### **5. Generate JWT (Testing Only)**  
**POST** `/generate-jwt`  
**Description**: Manually generate a token for testing (bypasses auth).  
**Body (JSON)**:  
```json
{"email": "user@example.com"}
```
**Test**:  
```bash
curl -X POST http://localhost:8000/generate-jwt \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com"}'
```
**Response**:  
```json
{"access_token": "eyJhbGciOi...", "token_type": "bearer"}
```

---

### 🔧 **Testing Tips**  
1. **Postman**:  
   - Use the **"Collections"** feature to save endpoints.  
   - For `/token`, set body type to `form-data`.  
   - For authenticated routes, add the JWT under **Headers** > `Authorization: Bearer <token>`.  

2. **Error Debugging**:  
   - Check logs for `500` errors (e.g., database connection).  
   - Validate JSON schema mismatches (e.g., `created_at` as `null`).  

3. **Database**:  
   - Use `psql` or Supabase Dashboard to verify user records after registration.  

---

### 📌 **Example Workflow**  
1. **Register** → `/register`  
2. **Login** → `/token`  
3. **Access Profile** → `/users/me` (with the token).  

Let me know if you'd like additional test cases or edge-case scenarios! 🚀