# app/main.py
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from datetime import datetime, timedelta
from jose import JWTError, jwt
from typing import Optional, List
from passlib.context import CryptContext
import databases
import sqlalchemy
import os
from dotenv import load_dotenv
from contextlib import asynccontextmanager
from uuid import UUID

# Load environment variables
load_dotenv()

# Database configuration - Fix the connection string formatting
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT')
DB_NAME = os.getenv('DB_NAME')
JWT_SECRET = os.getenv("JWT_SECRET")
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Properly escape the password and create the connection string
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# Initialize database connection
database = databases.Database(DATABASE_URL)
metadata = sqlalchemy.MetaData()

# Define users table
users = sqlalchemy.Table(
    "users",
    metadata,
    sqlalchemy.Column("user_id", sqlalchemy.UUID, primary_key=True, server_default=sqlalchemy.text("gen_random_uuid()")),
    sqlalchemy.Column("email", sqlalchemy.String, unique=True, index=True),
    sqlalchemy.Column("password_hash", sqlalchemy.String),  # Fixed column name
    sqlalchemy.Column("full_name", sqlalchemy.String(255)),
    sqlalchemy.Column("created_at", sqlalchemy.DateTime, server_default=sqlalchemy.func.now(), nullable=False),
    sqlalchemy.Column("last_login", sqlalchemy.DateTime, nullable=True)  # Added missing column
)

# Use FastAPI's lifespan instead of deprecated on_event
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Connect to database on startup
    await database.connect()
    
    # Create tables if they don't exist
    engine = sqlalchemy.create_engine(DATABASE_URL)
    metadata.create_all(engine)
    
    yield
    
    # Disconnect from database on shutdown
    await database.disconnect()

# Initialize FastAPI app with lifespan
app = FastAPI(title="FastAPI PostgreSQL Auth", lifespan=lifespan)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Pydantic models
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None

class UserBase(BaseModel):
    email: EmailStr
    full_name: str #new field

class UserCreate(UserBase):
    password: str

class User(UserBase):
    user_id: UUID
    created_at: datetime

    last_login: Optional[datetime] = None  
    
    class Config:
        from_attributes = True  # Updated from orm_mode

# OAuth2 setup
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# JWT functions
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, JWT_SECRET, algorithm="HS256")
    return encoded_jwt

# Password functions
def verify_password(plain_password, password_hash):
    return pwd_context.verify(plain_password, password_hash)

def get_password_hash(password):
    return pwd_context.hash(password)

# Database operations
async def get_user_by_email(email: str):
    query = sqlalchemy.select(
        users.c.user_id,
        users.c.email,
        users.c.password_hash,  # Changed from hashed_password
        users.c.full_name,
        users.c.created_at,
        users.c.last_login  # Added this column
    ).where(users.c.email == email)
    return await database.fetch_one(query)

async def create_user(user: UserCreate):
    hashed_password = get_password_hash(user.password)
    query = users.insert().values(
        email=user.email,
        password_hash=hashed_password,  # Changed from hashed_password
        full_name=user.full_name,
        # last_login is NULL by default
    )
    user_id = await database.execute(query)
    
    # Fetch the created user to return
    user_query = users.select().where(users.c.user_id == user_id)
    return await database.fetch_one(user_query)

# Auth functions
async def authenticate_user(email: str, password: str):
    user = await get_user_by_email(email)
    if not user:
        return False
    if not verify_password(password, user["password_hash"]):  # Changed from hashed_password
        return False
    return user

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
        token_data = TokenData(email=email)
    except JWTError:
        raise credentials_exception
    
    user = await get_user_by_email(email=token_data.email)
    if user is None:
        raise credentials_exception
    return user

async def get_current_active_user(current_user = Depends(get_current_user)):
    """if not current_user["is_active"]:
        raise HTTPException(status_code=400, detail="Inactive user")"""
    return current_user

# Routes
@app.post("/register", response_model=User)
async def register_user(user: UserCreate):
    db_user = await get_user_by_email(user.email)
    if db_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    created_user = await create_user(user)
    return {
    "user_id": created_user["user_id"],
    "email": created_user["email"],
    "full_name": created_user["full_name"],
    "created_at": created_user["created_at"] if "created_at" in created_user else datetime.utcnow(),
    "last_login": created_user["last_login"] if "last_login" in created_user else None
    }

@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = await authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["email"]}, expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/users/me", response_model=User)
async def read_users_me(current_user = Depends(get_current_active_user)):
    return {
        "user_id": current_user["user_id"],
        "email": current_user["email"],
        "full_name": current_user["full_name"],
        "created_at": current_user["created_at"],
        "last_login": current_user["last_login"] if "last_login" in current_user else None
        # Remove is_active from here
    }

# Generate JWT token manually (for testing)
@app.post("/generate-jwt")
async def generate_jwt(email: str):
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": email}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/")
async def root():
    return {"message": "Welcome to FastAPI with PostgreSQL Authentication"}

# Run the app
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)