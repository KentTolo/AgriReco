from fastapi import FastAPI, Depends, HTTPException, status
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from passlib.context import CryptContext
import joblib
import pandas as pd
from databases import Database
from typing import Optional
import uuid
from model2 import compare_crop_with_expert_advice

# Load ML model
model = joblib.load("crop_recommendation_model.pkl")

# Database configuration
# In your FastAPI app
DATABASE_URL = "postgresql://agroai_user:SecurePass123!@localhost:5432/agroai_db"
database = Database(DATABASE_URL)

# Security setup
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# Define FastAPI app
app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models
class CropRecommendationRequest(BaseModel):
    N: int
    P: int
    K: int
    temperature: float
    humidity: float
    ph: float
    rainfall: float

class UserCreate(BaseModel):
    email: str
    password: str
    full_name: Optional[str] = None

class UserInDB(UserCreate):
    user_id: uuid.UUID
    password_hash: str

class LoginRequest(BaseModel):
    email: str
    password: str
    
class CropComparisonRequest(BaseModel):
    desired_crop: str
    N: int
    P: int
    K: int
    temperature: float
    humidity: float
    ph: float
    rainfall: float    

# Database connection events
@app.on_event("startup")
async def startup():
    await database.connect()

@app.on_event("shutdown")
async def shutdown():
    await database.disconnect()

# Authentication functions
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

async def get_user(email: str):
    query = "SELECT * FROM users WHERE email = :email"
    return await database.fetch_one(query=query, values={"email": email})

async def authenticate_user(email: str, password: str):
    user = await get_user(email)
    if not user or not verify_password(password, user.password_hash):
        return False
    return user

# Routes
@app.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = await authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return {"access_token": user.user_id, "token_type": "bearer"}

@app.get("/")
async def read_root():
    return {"message": "Welcome to the Crop Recommendation API"}

# Recommendation endpoint
@app.post("/recommend")
async def recommend_crop(
    request: CropRecommendationRequest,
    user_id: str = Depends(oauth2_scheme)  # Add authentication dependency
):
    input_data = pd.DataFrame([{
        "N": request.N,
        "P": request.P,
        "K": request.K,
        "temperature": request.temperature,
        "humidity": request.humidity,
        "ph": request.ph,
        "rainfall": request.rainfall,
    }])
    
    try:
        prediction = model.predict(input_data)
        return {"recommended_crop": prediction[0]}
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Prediction failed: {str(e)}"
        )
# User registration endpoint
@app.post("/register")
async def register(user: UserCreate):
    # Check if user exists
    existing_user = await get_user(user.email)
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Hash password
    hashed_password = get_password_hash(user.password)
    
    # Create new user
    user_id = uuid.uuid4()
    query = """
        INSERT INTO users 
        (user_id, email, password_hash, full_name)
        VALUES (:user_id, :email, :password_hash, :full_name)
    """
    values = {
        "user_id": user_id,
        "email": user.email,
        "password_hash": hashed_password,
        "full_name": user.full_name
    }
    
    await database.execute(query=query, values=values)
    return {"message": "User created successfully"}

@app.on_event("startup")
async def startup():
    try:
        await database.connect()
        # Verify connection
        version = await database.fetch_val("SELECT version()")
        print(f"Connected to PostgreSQL: {version}")
    except Exception as e:
        print(f"Database connection failed: {str(e)}")
        raise

@app.get("/users/me")
async def read_users_me(user_id: str = Depends(oauth2_scheme)):
    query = "SELECT * FROM users WHERE user_id = :user_id"
    user = await database.fetch_one(query=query, values={"user_id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {
        "email": user.email,
        "full_name": user.full_name,
        "created_at": user.created_at
    }  
    
@app.get("/users/me")
async def read_current_user(user_id: str = Depends(oauth2_scheme)):
    query = "SELECT user_id, email, full_name, created_at FROM users WHERE user_id = :user_id"
    user = await database.fetch_one(query=query, values={"user_id": user_id})
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
        
    return {
        "email": user["email"],
        "full_name": user["full_name"],
        "created_at": user["created_at"]
    }    

# Add these imports at the top
from model2 import compare_crop_with_expert_advice

# Add this endpoint
class CropComparisonRequest(BaseModel):
    desired_crop: str
    N: int
    P: int
    K: int
    temperature: float
    humidity: float
    ph: float
    rainfall: float

@app.post("/compare_crop")
async def compare_crop(
    request: CropComparisonRequest,
    user_id: str = Depends(oauth2_scheme)
):
    try:
        # Map fields to match model2.py expectations
        ui_readings = {
            'temperature': request.temperature,
            'soil_ph': request.ph,
            'rainfall': request.rainfall,
            'humidity': request.humidity,
            'nitrogen': request.N,
            'phosphorus': request.P,
            'potassium': request.K
        }
        
        # Get expert analysis
        analysis = compare_crop_with_expert_advice(
            request.desired_crop,
            ui_readings
        )
        
        # Calculate compatibility score
        score = 100 - (analysis.count("⚠️") * 15)
        score = max(10, min(100, score))
        
        return {
            "compatibility_score": score,
            "feedback": analysis,
            "recommended_crop": request.desired_crop
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Analysis failed: {str(e)}"
        )    